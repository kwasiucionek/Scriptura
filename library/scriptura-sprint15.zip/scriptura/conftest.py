"""Ustawienia wymuszone dla testów: backendy zastępcze niezależnie od .env."""

import pytest


@pytest.fixture(autouse=True)
def _offline_backends(settings):
    settings.SEARCH_BACKEND = "db"
    settings.RERANKER_BACKEND = "none"
    settings.LLM_BACKEND = "echo"
    settings.DEMO_TOKEN = ""
