from corpus.importers.lxx import parse_tokens, psalm_to_mt


def test_psalm_mapping():
    assert psalm_to_mt(1, 1) == (1, 1)
    assert psalm_to_mt(9, 21) == (9, 21) and psalm_to_mt(9, 22) == (10, 1)
    assert psalm_to_mt(22, 1) == (23, 1)
    assert psalm_to_mt(113, 8) == (114, 8) and psalm_to_mt(113, 9) == (115, 1)
    assert psalm_to_mt(114, 9) == (116, 9) and psalm_to_mt(115, 1) == (116, 10)
    assert psalm_to_mt(146, 11) == (147, 11) and psalm_to_mt(147, 1) == (147, 12)
    assert psalm_to_mt(150, 6) == (150, 6) and psalm_to_mt(151, 1) is None


def test_parse_tokens():
    text = "ἀόρατος<S>701318</S><m>lxx.A.NSM</m><S>517</S><S>70518</S> ἀκατασκεύαστος<S>700529</S><m>lxx.A.NSM</m> <i>[/8]</i> καὶ<S>707031</S><m>lxx.C</m><S>2532</S><S>72518</S>"
    toks = parse_tokens(
        text, {"701318": "ἀόρατος", "700529": "ἀκατασκεύαστος", "707031": "καί"}
    )
    assert [(t.surface, t.lemma, t.strong, t.morph, t.pos) for t in toks] == [
        ("ἀόρατος", "ἀόρατος", "G517", "A.NSM", "A"),
        ("ἀκατασκεύαστος", "ἀκατασκεύαστος", "", "A.NSM", "A"),
        ("καὶ", "καί", "G2532", "C", "C"),
    ]
