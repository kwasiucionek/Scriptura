# Zakończenie Ewangelii Marka w świetle krytyki tekstu

## 1. Problem tekstualny

Fragment Mk 16,9-20 nie występuje w najstarszych kodeksach majuskułowych, Synajskim i Watykańskim, które kończą Ewangelię na Mk 16,8. Większość współczesnych komentatorów przyjmuje, że dłuższe zakończenie jest dodatkiem z II wieku, znanym już Ireneuszowi. Argument z krytyki wewnętrznej opiera się na słownictwie: w Mk 16,9-20 pojawia się kilkanaście wyrazów nieużywanych nigdzie indziej u Marka, a styl narracji różni się od charakterystycznego dla ewangelisty asyndetonu.

## 2. Zakończenie w Mk 16,8 jako zamierzone

Część egzegetów broni tezy, że urwane zakończenie „bały się bowiem” (Mk 16,8) jest świadomym zabiegiem literackim. Czytelnik zostaje postawiony wobec pustego grobu i wezwania do Galilei (por. Mk 14,28; 16,7), a Ewangelia nie domyka narracji, lecz przerzuca ją na wspólnotę. W tej perspektywie milczenie kobiet koresponduje z motywem tajemnicy mesjańskiej obecnym od Mk 1,34.

## 3. Wnioski

Niezależnie od rozstrzygnięcia genezy, Kościół przyjął Mk 16,9-20 jako tekst kanoniczny. Dla teologii biblijnej istotne pozostaje napięcie między świadectwem zmartwychwstania w Mk 16,6-7 a lękiem uczniów, które przewija się przez całą drugą część Ewangelii (Mk 8,31-33; 9,32; 10,32).
