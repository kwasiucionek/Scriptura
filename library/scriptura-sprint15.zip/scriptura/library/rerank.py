"""Reranker par (pytanie, chunk) przez TEI (text-embeddings-inference, endpoint /rerank).

Model: BAAI/bge-reranker-v2-m3 (wielojęzyczny) lub sdadas/polish-reranker-roberta-v3
(tylko polski) — wybór po stronie usługi TEI, kod jest ten sam.
RERANKER_BACKEND=none -> kolejność z RRF bez zmian.
"""

import json
import logging
import urllib.request

from django.conf import settings

from library.search import ChunkHit

log = logging.getLogger(__name__)


def rerank(query: str, hits: list[ChunkHit], top_k: int) -> list[ChunkHit]:
    """Zwraca top_k trafień w kolejności rerankera; przy błędzie usługi — kolejność wejściowa."""
    if settings.RERANKER_BACKEND != "tei" or not hits:
        return hits[:top_k]
    candidates = hits[: settings.RERANK_TOP_N]
    texts = [
        f"{h.title}\n{h.section}\n{h.text}"[: settings.RERANK_MAX_CHARS]
        for h in candidates
    ]
    try:
        scores = _tei_rerank(query, texts)
    except Exception as exc:
        log.warning("reranker niedostępny, zostaje kolejność RRF: %s", exc)
        return hits[:top_k]
    for h, s in zip(candidates, scores, strict=True):
        h.score = s
    return sorted(candidates, key=lambda h: -h.score)[:top_k]


def _tei_rerank(query: str, texts: list[str]) -> list[float]:
    req = urllib.request.Request(
        f"{settings.TEI_RERANK_URL}/rerank",
        data=json.dumps(
            {"query": query, "texts": texts, "raw_scores": False, "truncate": True}
        ).encode(),
        headers={
            "Content-Type": "application/json",
            **(
                {"Authorization": f"Bearer {settings.TEI_TOKEN}"}
                if settings.TEI_TOKEN
                else {}
            ),
        },
    )
    with urllib.request.urlopen(req, timeout=60) as resp:  # noqa: S310
        rows = json.load(resp)  # [{"index": i, "score": s}, ...] posortowane malejąco
    scores = [0.0] * len(texts)
    for r in rows:
        scores[r["index"]] = float(r["score"])
    return scores
