"""Serwis RAG: pytanie -> (chunki literatury + wersety) -> prompt -> strumień odpowiedzi.

Zdarzenia SSE (zgodne z GUI):
  sources  — kandydaci [n] z literatury + wersety znalezione po siglach w pytaniu
  delta    — fragment tekstu odpowiedzi
  done     — pełna odpowiedź, cytowane [n], weryfikacja sigli, czas, użyte tokeny
  error    — {"detail": ...}

Zasady w prompcie: tylko ze źródeł, cytuj [n], odróżniaj tekst / egzegezę /
interpretację, przypisuj tezy autorom, nie wymyślaj wersetów. Każde siglum
w odpowiedzi jest sprawdzane z korpusem — nieistniejące trafiają do `unverified`.
"""

import json
import logging
import re
import time
import urllib.request
from collections.abc import Iterator
from dataclasses import asdict, dataclass, field

from django.conf import settings

from corpus.models import Verse
from corpus.services import text as corpus_svc
from corpus.sigla import extract, format_ref, ordinal_range
from library.search import ChunkHit, expand_with_neighbors, retrieve
from rag.quotes import verify_quotes

log = logging.getLogger(__name__)

MODE_INSTRUCTIONS = {
    "scientific": (
        "TRYB NAUKOWY. Odbiorca to biblista lub student teologii. Używasz terminologii egzegetycznej, "
        "przytaczasz terminy hebrajskie i greckie w oryginale (z transliteracją przy pierwszym użyciu), "
        "wskazujesz rozbieżności między autorami i stan dyskusji, odróżniasz argumenty z krytyki tekstu, "
        "krytyki literackiej i historii tradycji. Cytujesz precyzyjnie, także drobne różnice między "
        "przekładami. 2–5 akapitów."
    ),
    "popular": (
        "TRYB POPULARNONAUKOWY. Odbiorca to zainteresowana osoba bez wykształcenia teologicznego. Piszesz "
        "jasno i konkretnie, bez żargonu; termin fachowy tylko wtedy, gdy go wyjaśnisz w tym samym zdaniu. "
        "Słowa hebrajskie i greckie podajesz w transliteracji, oryginał tylko gdy pytanie o niego prosi. "
        "Nie referujesz sporów specjalistycznych, chyba że pytanie ich dotyczy — wtedy jednym zdaniem. "
        "Nadal opierasz się wyłącznie na źródłach i cytujesz [n]; wolno opierać się na źródłach naukowych, "
        "ale mówisz o nich prostym językiem. 1–3 akapity."
    ),
}

SYSTEM_PROMPT = """Jesteś asystentem teologii biblijnej. Odpowiadasz po polsku.

Zasady:
1. Opierasz się WYŁĄCZNIE na dostarczonych źródłach. Jeśli źródła nie odpowiadają na pytanie, powiedz to wprost i nie zgaduj.
2. Każdą tezę zaczerpniętą z literatury oznaczasz numerem źródła w nawiasie kwadratowym, np. [2]. Tezy przypisujesz autorom po nazwisku („Rosik zauważa, że…").
3. Rozróżniasz trzy poziomy: co mówi tekst biblijny, co ustala egzegeza (autor X), co jest interpretacją teologiczną. Nie mieszasz ich.
4. Wersety cytujesz tylko z sekcji WERSETY, dokładnie w podanym brzmieniu, z siglum i skrótem przekładu. Nie cytujesz wersetów z pamięci.
5. Gdy autorzy się różnią, przedstawiasz obie pozycje z atrybucją; nie rozstrzygasz, która jest „prawdziwa".
   Źródło oznaczone jako RECENZJA to głos recenzenta o cudzej książce: tezy książki przypisuj jej autorowi, oceny — recenzentowi („Rosik w recenzji książki Niemasa zauważa…").
6. Nie używasz nagłówków Markdown ani list, chyba że pytanie wymaga wyliczenia."""


@dataclass
class VerseSource:
    ref: str
    work: str
    text: str


@dataclass
class AskResult:
    answer: str = ""
    citations: list[int] = field(default_factory=list)
    verified_refs: list[str] = field(default_factory=list)
    unverified_refs: list[str] = field(default_factory=list)
    quotes_verified: int = 0
    quotes_checked: int = 0
    quotes_altered: list[dict] = field(default_factory=list)
    refused: bool = False
    latency_ms: int = 0
    timings: dict = field(
        default_factory=dict
    )  # retrieval_ms (embedding+OpenSearch+reranker), llm_ms
    usage: dict = field(default_factory=dict)
    model: str = ""
    mode: str = "scientific"


# --- retrieval ------------------------------------------------------------


def verses_for_question(
    question: str, works: list[str] | None = None, limit: int = 40
) -> list[VerseSource]:
    refs = [r for m in extract(question) for r in m.refs]
    if not refs:
        return []
    work_objs = corpus_svc.active_works(works or list(settings.RAG_VERSE_WORKS))
    rows = corpus_svc.parallel(refs, work_objs)[:limit]
    out: list[VerseSource] = []
    for row in rows:
        for w in work_objs:
            vt = row.texts.get(w.code)
            if vt:
                out.append(VerseSource(ref=str(row.verse), work=w.code, text=vt.text))
    return out


def sigla_ranges(question: str) -> list[tuple[int, int]]:
    return [ordinal_range(r) for m in extract(question) for r in m.refs]


# --- prompt ---------------------------------------------------------------


def build_messages(
    question: str,
    chunks: list[ChunkHit],
    verses: list[VerseSource],
    mode: str = "scientific",
) -> list[dict]:
    src_lines = []
    for n, h in enumerate(chunks, start=1):
        kind = (
            " [RECENZJA KSIĄŻKI — tezy recenzowanego autora odróżniaj od ocen recenzenta]"
            if h.doc_type == "review"
            else ""
        )
        head = f"[{n}] {h.citation}{kind}" + (
            f" — sekcja: {h.section}" if h.section else ""
        )
        src_lines.append(f"{head}\n{h.text}")
    verse_lines = [f"{v.ref} ({v.work}): {v.text}" for v in verses]
    user = (
        f"PYTANIE:\n{question}\n\n"
        f"ŹRÓDŁA (literatura):\n"
        + ("\n\n".join(src_lines) if src_lines else "(brak)")
        + "\n\n"
        "WERSETY (tekst biblijny z korpusu):\n"
        + ("\n".join(verse_lines) if verse_lines else "(brak)")
    )
    system = (
        SYSTEM_PROMPT
        + "\n\n"
        + MODE_INSTRUCTIONS.get(mode, MODE_INSTRUCTIONS["scientific"])
    )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]


# --- LLM ------------------------------------------------------------------


def _ollama_stream(messages: list[dict]) -> Iterator[dict]:
    """Strumień NDJSON z /api/chat; ostatni rekord ma done=True i liczniki tokenów."""
    headers = {"Content-Type": "application/json"}
    if settings.OLLAMA_API_KEY:
        headers["Authorization"] = f"Bearer {settings.OLLAMA_API_KEY}"
    body = {
        "model": settings.OLLAMA_CHAT_MODEL,
        "messages": messages,
        "stream": True,
        "think": settings.RAG_THINK,
        "options": {
            "temperature": settings.RAG_TEMPERATURE,
            "num_ctx": settings.RAG_NUM_CTX,
        },
    }
    req = urllib.request.Request(
        f"{settings.OLLAMA_BASE_URL}/api/chat",
        data=json.dumps(body).encode(),
        headers=headers,
    )
    with urllib.request.urlopen(req, timeout=600) as resp:  # noqa: S310
        for line in resp:
            if line.strip():
                yield json.loads(line)


def _echo_stream(messages: list[dict]) -> Iterator[dict]:
    """Backend zastępczy bez LLM: streszcza, co zostało znalezione (testy, demo bez Ollamy)."""
    user = messages[-1]["content"]
    n_src = len(re.findall(r"^\[\d+\] ", user, re.M))
    text = (
        f"[tryb echo — bez modelu] Znaleziono {n_src} fragmentów literatury"
        + (" [1]" if n_src else "")
        + " oraz wersety z korpusu. Skonfiguruj LLM_BACKEND=ollama, aby uzyskać odpowiedź."
    )
    for word in text.split(" "):
        yield {"message": {"content": word + " "}, "done": False}
    yield {"done": True, "prompt_eval_count": 0, "eval_count": 0}


def llm_stream(messages: list[dict]) -> Iterator[dict]:
    if settings.LLM_BACKEND == "ollama":
        return _ollama_stream(messages)
    return _echo_stream(messages)


# --- weryfikacja ----------------------------------------------------------


def verify_refs(answer: str) -> tuple[list[str], list[str]]:
    """Sigla z odpowiedzi -> (istniejące w korpusie, nieistniejące)."""
    ok, bad = [], []
    for m in extract(answer):
        for ref in m.refs:
            label = format_ref(ref)
            s, e = ordinal_range(ref)
            if Verse.objects.filter(ordinal__range=(s, e)).exists():
                ok.append(label)
            else:
                bad.append(label)
    return sorted(set(ok)), sorted(set(bad))


# --- pełny przebieg -------------------------------------------------------


def registers_for_mode(mode: str) -> list[str] | None:
    """Tryb naukowy: tylko źródła naukowe i mieszane; popularny: wszystkie (bez filtra)."""
    if mode == "scientific":
        return ["scientific", "mixed"]
    return None


def ask(
    question: str,
    authors: list[str] | None = None,
    works: list[str] | None = None,
    mode: str | None = None,
    access: list[str] | None = None,
    user_id: int | None = None,
    personal_only: bool = False,
) -> Iterator[tuple[str, dict]]:
    """Generator (event, data) do zaserwowania jako SSE.
    `access` — poziomy dostępu użytkownika (rag.access.access_for_user); None = RAG_ACCESS."""
    t0 = time.monotonic()
    mode = mode if mode in MODE_INSTRUCTIONS else settings.RAG_DEFAULT_MODE
    registers = registers_for_mode(mode)
    ranges = sigla_ranges(question)
    try:
        chunks = retrieve(
            question,
            k=settings.RAG_TOP_K,
            access=access,
            authors=authors,
            sigla=ranges or None,
            registers=registers,
            user_id=user_id,
            personal_only=personal_only,
        )
        if (
            ranges and not chunks
        ):  # sigla w pytaniu, ale nikt o tym nie pisze -> bez filtra sigli
            chunks = retrieve(
                question,
                k=settings.RAG_TOP_K,
                access=access,
                authors=authors,
                registers=registers,
                user_id=user_id,
                personal_only=personal_only,
            )
        chunks = expand_with_neighbors(chunks, settings.RAG_CONTEXT_NEIGHBORS)
        t_v = time.monotonic()
        verses = verses_for_question(question, works)
        verses_ms = int((time.monotonic() - t_v) * 1000)
        t_retrieval = int((time.monotonic() - t0) * 1000)
    except Exception as exc:
        log.exception("retrieval")
        yield "error", {"detail": f"Błąd wyszukiwania: {exc}"}
        return

    sources = [
        {
            "n": n,
            "title": h.title,
            "authors": h.authors,
            "citation": h.citation,
            "section": h.section,
            "doc_type": h.doc_type,
            "year": h.year,
            "url": h.url,
            "sigla": h.sigla,
            "snippet": h.text[:600],
            "access": h.access,
            "register": h.register,
            "personal": h.access == "personal",
        }
        for n, h in enumerate(chunks, start=1)
    ]
    yield "sources", {"chunks": sources, "verses": [asdict(v) for v in verses]}

    result = AskResult(
        model=settings.OLLAMA_CHAT_MODEL
        if settings.LLM_BACKEND == "ollama"
        else "echo",
        mode=mode,
    )
    from library.search import LAST_TIMINGS

    result.timings["retrieval_ms"] = t_retrieval
    result.timings.update(LAST_TIMINGS)
    result.timings["verses_ms"] = verses_ms
    t_llm = time.monotonic()
    if not chunks and not verses:
        result.refused = True
        result.answer = "W dostępnych źródłach nie ma materiału, który pozwoliłby odpowiedzieć na to pytanie."
        yield "delta", {"text": result.answer}
    else:
        parts: list[str] = []
        try:
            for rec in llm_stream(build_messages(question, chunks, verses, mode)):
                if rec.get("done"):
                    result.usage = {
                        "prompt_tokens": rec.get("prompt_eval_count", 0),
                        "completion_tokens": rec.get("eval_count", 0),
                    }
                    break
                piece = rec.get("message", {}).get("content", "")
                if piece:
                    parts.append(piece)
                    yield "delta", {"text": piece}
        except Exception as exc:
            log.exception("llm")
            yield "error", {"detail": f"Błąd modelu: {exc}"}
            return
        result.answer = "".join(parts).strip()
        result.refused = bool(
            re.search(
                r"nie (?:zawiera\w*|ma|znajduj\w*|pozwala\w*)\b.{0,60}(?:informacj|źródł|materiał|odpowied)"
                r"|brak (?:informacji|źródeł|materiału)",
                result.answer[:400],
                re.I,
            )
        )

    result.timings["llm_ms"] = int((time.monotonic() - t_llm) * 1000)
    result.citations = sorted(
        {
            int(n)
            for n in re.findall(r"\[(\d+)\]", result.answer)
            if 0 < int(n) <= len(chunks)
        }
    )
    result.verified_refs, result.unverified_refs = verify_refs(result.answer)
    qr = verify_quotes(
        result.answer,
        [(f"{v.ref} ({v.work})", v.text) for v in verses],
        [(f"[{n}] {h.citation}", h.text) for n, h in enumerate(chunks, start=1)],
    )
    result.quotes_verified, result.quotes_checked = qr.verified, qr.checked
    result.quotes_altered = [asdict(a) for a in qr.altered]
    result.latency_ms = int((time.monotonic() - t0) * 1000)
    yield "done", asdict(result)
