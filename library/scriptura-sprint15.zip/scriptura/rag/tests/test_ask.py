import json
import re

import pytest
from django.test import Client

from corpus.importers.base import VerseRecord, import_records
from corpus.models import Work, WorkKind
from library.models import Author, Chunk, Document
from rag import service

pytestmark = pytest.mark.django_db


@pytest.fixture
def data():
    w = Work.objects.create(
        code="BG1632", name="BG", language="pl", kind=WorkKind.TRANSLATION
    )
    import_records(
        w,
        iter(
            [
                VerseRecord("Mark", 16, v, f"Werset {v} rozdziału szesnastego.")
                for v in range(1, 21)
            ]
        ),
    )
    a = Author.objects.create(name="Jan Testowy", slug="jan-testowy")
    d = Document.objects.create(
        title="O zakończeniu Marka", year=2024, journal="Test", access="open"
    )
    d.authors.add(a)
    Chunk.objects.create(
        document=d,
        order=0,
        section="1",
        text="Dłuższe zakończenie Mk 16,9-20 jest dodatkiem.",
        sigla=[{"ref": "Mk 16,9-20", "start": 48016009, "end": 48016020}],
    )
    Chunk.objects.create(
        document=d,
        order=1,
        section="2",
        text="Tajemnica mesjańska od Mk 1,34.",
        sigla=[{"ref": "Mk 1,34", "start": 48001034, "end": 48001034}],
    )
    priv = Document.objects.create(title="Prywatne", access="private")
    Chunk.objects.create(
        document=priv, order=0, text="Tajemnica mesjańska prywatnie.", sigla=[]
    )
    return d


def _events(resp):
    body = b"".join(resp.streaming_content).decode()
    return [
        (e, json.loads(d)) for e, d in re.findall(r"event: (\w+)\ndata: (.*)\n", body)
    ]


def test_ask_with_siglum_filters_chunks_and_adds_verses(data):
    c = Client(HTTP_HOST="localhost")
    ev = _events(
        c.post(
            "/ask/stream",
            data=json.dumps({"question": "Co wiadomo o Mk 16,9-20?"}),
            content_type="application/json",
        )
    )
    assert [e for e, _ in ev][0] == "sources" and ev[-1][0] == "done"
    src = ev[0][1]
    assert [s["section"] for s in src["chunks"]] == ["1"]
    assert len(src["verses"]) == 12 and src["verses"][0]["ref"] == "Mk 16,9"
    assert ev[-1][1]["citations"] == [1]


def test_private_documents_are_invisible_by_default(data):
    hits = service.retrieve("tajemnica mesjańska", k=5)
    assert [h.title for h in hits] == ["O zakończeniu Marka"]


def test_verify_refs(data):
    ok, bad = service.verify_refs("Zob. Mk 16,8 oraz Rdz 1,1.")
    assert ok == ["Mk 16,8"] and bad == ["Rdz 1,1"]


def test_refusal_when_nothing_found(data):
    c = Client(HTTP_HOST="localhost")
    ev = _events(
        c.post(
            "/ask/stream",
            data=json.dumps({"question": "Ile kosztuje bilet do muzeum?"}),
            content_type="application/json",
        )
    )
    assert ev[-1][1]["refused"] is True


def test_demo_token(settings, data):
    settings.DEMO_TOKEN = "sekret"
    c = Client(HTTP_HOST="localhost")
    assert (
        c.post("/ask/stream", data="{}", content_type="application/json").status_code
        == 401
    )
    r = c.post(
        "/ask/stream",
        data=json.dumps({"question": "Mk 16,8"}),
        content_type="application/json",
        HTTP_X_DEMO_TOKEN="sekret",
    )
    assert r.status_code == 200


def test_mode_filters_registers_and_changes_prompt(data):
    from library.models import Document
    from rag import service

    Document.objects.filter(title="O zakończeniu Marka").update(register="popular")
    sci = service.retrieve(
        "tajemnica mesjańska", k=5, registers=service.registers_for_mode("scientific")
    )
    pop = service.retrieve(
        "tajemnica mesjańska", k=5, registers=service.registers_for_mode("popular")
    )
    assert sci == [] and [h.title for h in pop] == ["O zakończeniu Marka"]
    msgs_pop = service.build_messages("q", [], [], mode="popular")
    msgs_sci = service.build_messages("q", [], [], mode="scientific")
    assert (
        "POPULARNONAUKOWY" in msgs_pop[0]["content"]
        and "NAUKOWY" in msgs_sci[0]["content"]
    )

    c = Client(HTTP_HOST="localhost")
    ev = _events(
        c.post(
            "/ask/stream",
            data=json.dumps(
                {"question": "Co wiadomo o Mk 16,9-20?", "mode": "popular"}
            ),
            content_type="application/json",
        )
    )
    assert ev[-1][1]["mode"] == "popular"


def test_expand_with_neighbors(data):
    from library.search import ChunkHit, expand_with_neighbors

    d = Document.objects.get(title="O zakończeniu Marka")
    hit = ChunkHit(chunk_id=0, document_id=d.id, order=1, title=d.title, authors=[], citation="", doc_type="article",
                   year=None, url="", section="2", text="Tajemnica mesjańska od Mk 1,34.", sigla=[], score=1.0, access="open")  # fmt: skip
    (out,) = expand_with_neighbors([hit], 1)
    assert (
        out.text.startswith("Dłuższe zakończenie") and "Tajemnica mesjańska" in out.text
    )
    assert expand_with_neighbors([hit], 0)[0].text.count("\n") == out.text.count(
        "\n"
    )  # radius 0 bez zmian (obiekt już rozszerzony)
