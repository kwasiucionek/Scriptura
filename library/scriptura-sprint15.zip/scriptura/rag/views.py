"""Endpointy czatu: GUI, strumień SSE /ask/stream, historia rozmów, logowanie."""

import json

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.core.exceptions import ValidationError
from django.http import HttpRequest, HttpResponse, JsonResponse, StreamingHttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST

from corpus.services import text as corpus_svc
from library.models import Author
from rag import service
from rag.access import access_for_user, allowed_modes
from rag.models import Conversation, Message
from rag.personal import ProfileForm, UploadForm, delete_personal, ingest_personal

EXAMPLES = [
    {
        "title": "Pytanie o werset",
        "q": "Jak Majewski interpretuje relację Wj 40 do Rdz 1?",
    },
    {
        "title": "Termin oryginalny",
        "q": "Co oznacza miszkan i jak oddają go polskie przekłady?",
    },
    {"title": "Tekst w oryginale", "q": "Jak brzmi Rdz 1,2 po hebrajsku i grecku?"},
    {
        "title": "Zakres wiedzy",
        "q": "Jak egzegeci interpretują zakończenie Ewangelii Marka (Mk 16,9-20)?",
    },
]


def _user(request: HttpRequest):
    return request.user if request.user.is_authenticated else None


def index(request: HttpRequest) -> HttpResponse:
    if not request.user.is_authenticated and not settings.ALLOW_ANONYMOUS:
        return redirect(f"{settings.LOGIN_URL}?next=/")
    user = _user(request)
    modes = allowed_modes(user)
    default_mode = (
        settings.RAG_DEFAULT_MODE if settings.RAG_DEFAULT_MODE in modes else modes[0]
    )
    return render(
        request,
        "rag/index.html",
        {
            "examples_json": json.dumps(EXAMPLES, ensure_ascii=False),
            "authors": Author.objects.all(),
            "works": corpus_svc.active_works(),
            "default_works": list(settings.RAG_VERSE_WORKS),
            "default_mode": default_mode,
            "allowed_modes": modes,
            "access_levels": access_for_user(user),
            "demo_token_required": bool(settings.DEMO_TOKEN),
            "user": request.user,
            "allow_anonymous": settings.ALLOW_ANONYMOUS,
        },
    )


def _sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


@csrf_exempt
@require_POST
def ask_stream(request: HttpRequest) -> HttpResponse:
    if (
        settings.DEMO_TOKEN
        and request.headers.get("X-Demo-Token") != settings.DEMO_TOKEN
    ):
        return JsonResponse({"detail": "Nieprawidłowy token dostępu"}, status=401)
    user = _user(request)
    if user is None and not settings.ALLOW_ANONYMOUS:
        return JsonResponse({"detail": "Wymagane logowanie"}, status=401)
    try:
        payload = json.loads(request.body or b"{}")
    except json.JSONDecodeError:
        return JsonResponse({"detail": "Niepoprawny JSON"}, status=400)
    question = (payload.get("question") or "").strip()
    if len(question) < 3:
        return JsonResponse({"detail": "Pytanie jest za krótkie"}, status=400)
    authors = [a for a in (payload.get("authors") or []) if a]
    works = [w for w in (payload.get("works") or []) if w]
    modes = allowed_modes(user)
    mode = payload.get("mode") or settings.RAG_DEFAULT_MODE
    if mode not in modes:
        mode = modes[0]
    access = access_for_user(user)

    conversation = None
    if user is not None:
        conv_id = payload.get("conversation_id")
        if conv_id:
            conversation = Conversation.objects.filter(id=conv_id, user=user).first()
        if conversation is None:
            conversation = Conversation.objects.create(
                user=user, title=question[:200], mode=mode
            )
        Message.objects.create(
            conversation=conversation, role="user", content=question,
            meta={"authors": authors, "works": works, "mode": mode},
        )  # fmt: skip

    def gen():
        sources_payload: dict = {}
        for event, data in service.ask(
            question,
            authors=authors or None,
            works=works or None,
            mode=mode,
            access=access,
            user_id=user.id if user else None,
            personal_only=bool(payload.get("personal_only")) and user is not None,
        ):
            if event == "sources":
                sources_payload = data
            if event == "done" and conversation is not None:
                Message.objects.create(
                    conversation=conversation, role="assistant", content=data.get("answer", ""),
                    meta={"result": data, "sources": sources_payload},
                )  # fmt: skip
                conversation.save(update_fields=["modified"])
                data = {**data, "conversation_id": conversation.id}
            yield _sse(event, data)

    resp = StreamingHttpResponse(gen(), content_type="text/event-stream; charset=utf-8")
    resp["Cache-Control"] = "no-cache"
    resp["X-Accel-Buffering"] = "no"  # nginx: nie buforuj strumienia
    return resp


@login_required
@require_GET
def conversations(request: HttpRequest) -> JsonResponse:
    rows = [
        {
            "id": c.id,
            "title": c.title,
            "mode": c.mode,
            "modified": c.modified.isoformat(timespec="minutes"),
        }
        for c in request.user.conversations.all()[:50]
    ]
    return JsonResponse({"conversations": rows})


@login_required
@require_GET
def conversation_detail(request: HttpRequest, pk: int) -> JsonResponse:
    conv = get_object_or_404(Conversation, pk=pk, user=request.user)
    msgs = [
        {"role": m.role, "content": m.content, "meta": m.meta}
        for m in conv.messages.all()
    ]
    return JsonResponse(
        {"id": conv.id, "title": conv.title, "mode": conv.mode, "messages": msgs}
    )


@login_required
@require_POST
def conversation_delete(request: HttpRequest, pk: int) -> JsonResponse:
    conv = get_object_or_404(Conversation, pk=pk, user=request.user)
    conv.delete()
    return JsonResponse({"deleted": pk})


@login_required
def account(request: HttpRequest) -> HttpResponse:
    """Konto: dane, zmiana hasła, materiały osobiste (wgrywanie / usuwanie)."""
    user = request.user
    profile_form = ProfileForm(instance=user)
    password_form = PasswordChangeForm(user)
    upload_form = UploadForm()
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "profile":
            profile_form = ProfileForm(request.POST, instance=user)
            if profile_form.is_valid():
                profile_form.save()
                messages.success(request, "Dane zapisane.")
                return redirect("rag:account")
        elif action == "password":
            password_form = PasswordChangeForm(user, request.POST)
            if password_form.is_valid():
                password_form.save()
                update_session_auth_hash(request, user)
                messages.success(request, "Hasło zmienione.")
                return redirect("rag:account")
        elif action == "upload":
            upload_form = UploadForm(request.POST, request.FILES)
            if upload_form.is_valid():
                try:
                    doc = ingest_personal(user, upload_form)
                    messages.success(
                        request, f"Dodano „{doc.title}” ({doc.chunk_count} fragmentów)."
                    )
                    return redirect("rag:account")
                except ValidationError as exc:
                    upload_form.add_error(None, exc)
                except Exception as exc:  # noqa: BLE001 — błąd parsowania/indeksu pokazujemy użytkownikowi
                    upload_form.add_error(
                        None, f"Nie udało się przetworzyć pliku: {exc}"
                    )
        elif action == "delete":
            try:
                delete_personal(user, int(request.POST.get("doc_id", 0)))
                messages.success(request, "Materiał usunięty.")
            except Exception:  # noqa: BLE001
                messages.error(request, "Nie znaleziono materiału.")
            return redirect("rag:account")
    docs = user.documents.order_by("-created")
    return render(
        request,
        "rag/account.html",
        {
            "profile_form": profile_form,
            "password_form": password_form,
            "upload_form": upload_form,
            "docs": docs,
            "access_levels": access_for_user(user),
            "limits": {
                "mb": settings.PERSONAL_MAX_MB,
                "docs": settings.PERSONAL_MAX_DOCS,
            },
        },
    )
